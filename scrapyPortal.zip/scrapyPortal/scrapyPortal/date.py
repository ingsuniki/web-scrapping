# import datetime

# # # x = datetime.datetime(2020/5/17)
# # y = datetime.datetime.now()
# # y1 =  y.strftime("%f") + 'Portal'  + y.strftime("%Y") + y.strftime("%m") + y.strftime("%d") 

# # # print(x)
# # print(y)
# # print(y1)

# # awal = " Senin, 6 Juli 2020 14:50 WIB"

# # titleDates = " Senin, 6 Juli 2020 14:50 WIB"
# titleDates = " Selasa, 7 Juli 2020 10:22"
# arrDate = titleDates.split(" ")
# msArrDate = arrDate[5].split(":")

# if arrDate[3] == "Januari"         :
#      month = 1
# elif arrDate[3] == "Februari"      :
#      month = 2
# elif arrDate[3] == "Maret"         :
#      month = 3
# elif arrDate[3] == "April"         :
#      month = 4
# elif arrDate[3] == "Mei"           :
#      month = 5
# elif arrDate[3] == "Juni"          :
#      month = 6
# elif arrDate[3] == "Juli"          :
#      month = 7
# elif arrDate[3] == "Agustus"       :
#      month = 8
# elif arrDate[3] == "September"     :
#      month = 9
# elif arrDate[3] == "Oktober"       :
#      month = 10
# elif arrDate[3] == "November"      :
#      month = 11
# elif arrDate[3] == "Desember"      :
#      month = 12

# getDateMs = datetime.datetime(int(arrDate[4]),month, int(arrDate[2]), int(msArrDate[0]), int(msArrDate[1]))
# print(getDateMs)
# # datetime.datetime(2020, 5, 17)
# # string_date = datetime.datetime(getDateMs)
# # print(string_date)

# #  datetime.datetime(2020, 7, 6, 16, 0, 10, 261138),
# # awal = " Senin, 6 Juli 2020 14:50 WIB"
# # getDateMs = (`${month} ${arrDate[2]} ${arrDate[4]} ${arrDate[5]}  `);
        
#      #    var getDateMs = (`${month} ${arrDate[2]} ${arrDate[4]} ${arrDate[5]}  `);
#      #    const nowDate = new Date();


# for i in range(1,5):
#     if i is 2:
#         print("nilai",i,"ditemukan")
#         continue
#         print("nilai setelah continue") # nilai tidak akan dicetak jika proses terpenuhi
#     print("nilai saat ini adalah",i)
 
# hasil :
# nilai saat ini adalah 1
# nilai 2 ditemukan
# nilai saat ini adalah 3
# nilai saat ini adalah 4

# for i in range(1,5):
#     if i is 2:
#         print("nilai",i,"ditemukan")
#         pass
#         print("nilai setelah pass")
#     print("nilai saat ini adalah",i)

import  datetime

a = datetime.datetime.utcnow()

print(a)
# -*- coding: utf-8 -*-
import scrapy
# install pip install pytz
import pytz, datetime
import re
import logging
import os 
import json
import math


from scrapy import Request
from scrapy.crawler import CrawlerProcess 
from ..items import ScrapyportalItem 
# from ..items import ScrapyportalItem 

# Code for running the file 
# scrapy crawl antaranewsAceh  -L WARN
# Get current times
TIMESTAMP_NOW = datetime.datetime.now()

# Setting Umum untuk Spider
SPIDER_NAME     =   "balipuspa"
DOMAIN_NAME     =   ['www.balipuspanews.com']
CONCAT_URL      =   'https://www.balipuspanews.com/bali/badung'
STARTING_URL    =   [CONCAT_URL]
PATH_LOG = "../LogData/" 
PATH_LOG_ERR = "../LogData_Err/"

# # CSS SELECTOR
CSS_LINKS           =   '.td-block-span6 h3 '
CSS_ATTRIBUT        =   SPIDER_NAME
CSS_URL             =   'a'
CSS_TITLE           =   'header h1.post-title'
CSS_AUTHOR          =   'AntaraNews'
CSS_DATETIME_STRING =   'span.article-date'
CSS_DATETIME_MS     =   'span.article-date'
CSS_TIMESTAMP       =   TIMESTAMP_NOW
CSS_IMAGE           =   'header.post-header.clearfix img'
# //*[not(self::script or self::style)]/text() => code for ignore script and jquery text style
XPATH_TEXT            =   "//*[not(self::script or self::style)]/div[@class='post-content clearfix']/text()"
LOAD_MORE             =   ".td-load-more-wrap.td-load-more-infinite-wrap a"
# CSS_LOCATION        =   'Aceh'

# Pattern for cleanup data text
PATTERN_REGEX       =   "\\'"
# Len Page for crawling past data 
LEN_PAGE = 1

#  function for split and conversi date string into data date type
def dateTime(input_string):
    titleDates = input_string
    arrDate = titleDates.split(" ")
    msArrDate = arrDate[5].split(":")

    if arrDate[3] == "Januari"         :
        month = 1
    elif arrDate[3] == "Februari"      :
        month = 2
    elif arrDate[3] == "Maret"         :
        month = 3
    elif arrDate[3] == "April"         :
        month = 4
    elif arrDate[3] == "Mei"           :
        month = 5
    elif arrDate[3] == "Juni"          :
        month = 6
    elif arrDate[3] == "Juli"          :
        month = 7
    elif arrDate[3] == "Agustus"       :
        month = 8
    elif arrDate[3] == "September"     :
        month = 9
    elif arrDate[3] == "Oktober"       :
        month = 10
    elif arrDate[3] == "November"      :
        month = 11
    elif arrDate[3] == "Desember"      :
        month = 12

    # conversi date string into data date type
    # getDateMs = datetime.datetime(int(arrDate[4]),month, int(arrDate[2]), int(msArrDate[0]), int(msArrDate[1]))
    getDateMs = datetime.datetime(int(arrDate[4]),month, 
        int(arrDate[2]), int(msArrDate[0]), int(msArrDate[1]))
    return getDateMs
    # print(getDateMs)

# class AntaranewsSpider
class AntaranewsSpider(scrapy.Spider):
    try:
        os.mkdir(PATH_LOG)      
        os.mkdir(PATH_LOG_ERR)      
    except Exception : 
        pass

    name = SPIDER_NAME
    allowed_domains = DOMAIN_NAME
    start_urls = STARTING_URL
    page_number = 1
            
    headers = {
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
    }        
    
    def __init__(self, *args, **kwargs):
        logger = logging.getLogger('scrapy.spidermiddlewares.httperror')
        logger.setLevel(logging.WARNING)
        super().__init__(*args, **kwargs)

    # collect link url in front windows
    def parse(self, response):
        try:
            DIV_link = response.css(CSS_LINKS)
            for dlink in DIV_link: 
                direct_link = dlink.css(CSS_URL).css('::attr(href)').get()
                link = response.urljoin(direct_link)        
                yield Request(url=link, callback=self.parse_mainportal)
        except:
            pass
            
    # main function or main url looping for crawling
    def parse_mainportal(self, response):
        try:
            items = ScrapyportalItem()  
        
            # declare and find data in url       
            css_url                 = response.url
            print(css_url)
          #   css_titles              = response.css(CSS_TITLE).css('::text').get()
          # #   css_authors             = response.css(CSS_AUTHOR).css('::text').get()
          #   css_authors             = CSS_AUTHOR
          #   css_datetime_strings    = response.css(CSS_DATETIME_STRING).css('::text').get()
          #   css_datime_mss          = dateTime(css_datetime_strings)
          #   css_timestamps          = CSS_TIMESTAMP
          #   css_images              = response.css(CSS_IMAGE).css('::attr(data-src)').getall()
          #   css_texts               = response.xpath(XPATH_TEXT).getall()
          #   text_join               = " ".join(css_texts)
          #   text_clean              = re.sub(PATTERN_REGEX, "", text_join)
          #   # css_location               = CSS_LOCATION
          #   # print (css_images)

        
          #   # enter data into items[] before save to data base            
          #   # items['_id']                = css_datime_mss.strftime("%H") + css_datime_mss.strftime("%M") + SPIDER_NAME + css_datime_mss.strftime("%Y") + css_datime_mss.strftime("%m") + css_datime_mss.strftime("%d")
          #   items['_id']                = css_datime_mss.strftime("%H") + css_datime_mss.strftime("%M") + SPIDER_NAME 
          #   items['_id']                = items['_id'] + css_datime_mss.strftime("%Y") + css_datime_mss.strftime("%m") + css_datime_mss.strftime("%d")
          #   items['attribut']           = SPIDER_NAME
            items['url']                = css_url
          #   items['title']              = css_titles
          #   items['author']             = css_authors
          #   items['datetime_string']    = css_datetime_strings
          #   items['datetime_ms']        = css_datime_mss.astimezone(pytz.utc)
          #   items['timestamp']          = css_timestamps.astimezone(pytz.utc)
          #   items['images']             = css_images
          #   items['text']               = text_clean

            # Skip save data if data is not found / empty
          #   if items['_id']               == None or items['_id'] == "" :
          #            pass
          #   elif items['attribut']        == None or items['attribut'] == "" :
          #       pass
          #   elif items['url']             == None or items['url'] == "" :
          #       pass
          #   elif items['title']           == None or items['title'] == "" :
          #       pass
          #   elif items['author']          == None or items['author'] == "" :
          #       pass
          #   elif items['datetime_string'] == None or items['datetime_string'] == "" :
          #       pass
          #   elif ['datetime_ms']          == None or items['datetime_ms'] == "" :
          #       pass
          #   elif items['timestamp']       == None or items['timestamp'] == "" :
          #       pass
          #   elif items['images']          == None or len(items['images']) < 1 :
          #       pass
          #   elif items['text']            == None or items['text'] == "" :
          #       pass
          #   else :
          #       yield items

            # yield items

            # Print _id for check data _id
            # print ("    _id url crawling " + items['text'])
            # print ("    _id url crawling " + items['images'])
            
            # Compile and merging get url by lenght for crawling past data
          #   next_page = CONCAT_URL + "/" + str(AntaranewsSpider.page_number) 
          #   if AntaranewsSpider.page_number <= LEN_PAGE:
          #       AntaranewsSpider.page_number += 1
          #       yield response.follow(next_page, callback=self.parse)
          
            # Compile and merging get url by lenght for crawling past data
          #   next_page = response.css(LOAD_MORE).extract()
          #   print(next_page)
          #   nomer = 0 
          #   if nomer < 10:
          #       nomer += 1
          #       yield response.follow(next_page, callback=self.parse)      

          #   TIMESTAMP_FINAL = datetime.datetime.now()
          #   last = TIMESTAMP_FINAL - TIMESTAMP_NOW 
          #   insert_log =        "    Waktu Awal Crawling Adalah    : " + str(TIMESTAMP_NOW) + "  \n  "
          #   insert_log = insert_log + "  Waktu Selesai Crawling Adalah : " + str(TIMESTAMP_FINAL) + "  \n  "
          #   insert_log = insert_log + "  Lama Waktu Crawling Adalah    : " + str(last) + "  \n  "
          #   print (insert_log)

          #   # Save Log data / long data while crawling
          #   try:
          #       with open( PATH_LOG + SPIDER_NAME +'.log', 'w') as log_file:
          #           json.dump(insert_log, log_file)     
          #   except Exception : 
          #       pass

            # Save Log data Error
        except Exception as e:
            insert_log = "Waktu Error Adalah :" + str(TIMESTAMP_NOW) + "  \n  dan log Errornya adalah :  \n  " + str(e)
            try:
                with open( PATH_LOG_ERR + SPIDER_NAME +'.log', 'w') as log_file:
                    json.dump(insert_log, log_file)     
            except Exception : 
                pass 

# # for execute / run program
# process = CrawlerProcess()
# process.crawl(AntaranewsSpider)
# process.start()
        
       
       
       
       
      
      */30 * * * * cd /home/support/Apps/crawlers/online-media-crawler-py/scrapyPortal/scrapyPortal && /usr/local/bin/scrapy crawl antaranewsAceh -L WARN

        AntaraNewsAceh.js
       /AntaraNewsAmbon.js
       /AntaraNewsBabel.js
       /AntaraNewsBali.js
       /AntaraNewsBanten.js
       /AntaraNewsBengkulu.js
       /AntaraNewsBola.js
       /AntaraNewsDunia.js
       /AntaraNewsEkonomi.js
       /AntaraNewsGorontalo.js
       /AntaraNewsHiburan.js
       /AntaraNewsHukum.js
       /AntaraNewsHumaniora.js
       /AntaraNewsJabar.js
       /AntaraNewsJambi.js
       /AntaraNewsJatim.js
       /AntaraNewsJogja.js
       /AntaraNewsKalbar.js
       /AntaraNewsKalsel.js
       /AntaraNewsKaltara.js
       3 */1 * * * /AntaraNewsKalteng.js
       3 */1 * * * /AntaraNewsKaltim.js
       3 */1 * * * /AntaraNewsKepri.js
       3 */1 * * * /AntaraNewsKl.js
       3 */1 * * * /AntaraNewsKupang.js
       3 */1 * * * /AntaraNewsLampung.js
       3 */1 * * * /AntaraNewsLifes.js
       3 */1 * * * /AntaraNewsMakassar.js
       3 */1 * * * /AntaraNewsManado.js
       3 */1 * * * /AntaraNewsMataram.js
       4 */1 * * * /AntaraNewsMegapolitan.js
       4 */1 * * * /AntaraNewsMetro.js
       4 */1 * * * /AntaraNewsPapua.js
       4 */1 * * * /AntaraNewsPapuaBarat.js
       4 */1 * * * /AntaraNewsPolitik.js
       4 */1 * * * /AntaraNewsRiau.js
       4 */1 * * * /AntaraNewsSport.js
       4 */1 * * * /AntaraNewsSulteng.js
       4 */1 * * * /AntaraNewsSultra.js
       4 */1 * * * /AntaraNewsSumbar.js
       5 */1 * * * /AntaraNewsSumsel.js
       5 */1 * * * /AntaraNewsSumut.js
       5 */1 * * * /AntaraNewsTekno.js
       5 */1 * * * /AntaraNewsWartaBumi.js
    #======================================================================================================================================================================
       5 */1 * * * /BalipuspanewsBadung.js
       5 */1 * * * /BalipuspanewsBangli.js
       5 */1 * * * /BalipuspanewsBuleleng.js
       5 */1 * * * /BalipuspanewsDenpasar.js
       5 */1 * * * /BalipuspanewsEkonomi.js
       5 */1 * * * /BalipuspanewsGianyar.js
       6 */1 * * * /BalipuspanewsHobi.js
       6 */1 * * * /BalipuspanewsHukum.js
       6 */1 * * * /BalipuspanewsInspirasi.js
       6 */1 * * * /BalipuspanewsInternasional.js
       6 */1 * * * /BalipuspanewsJakarta.js
       6 */1 * * * /BalipuspanewsJawabarat.js
       6 */1 * * * /BalipuspanewsJembrana.js
       6 */1 * * * /BalipuspanewsKarangasem.js
       6 */1 * * * /BalipuspanewsKesehatan.js
       6 */1 * * * /BalipuspanewsKlungkung.js
       7 */1 * * * /BalipuspanewsPeristiwa.js
       7 */1 * * * /BalipuspanewsPolitik.js
       7 */1 * * * /BalipuspanewsReligi.js
       7 */1 * * * /BalipuspanewsSeni.js
       7 */1 * * * /BalipuspanewsSosial.js
       7 */1 * * * /BalipuspanewsSport.js
       7 */1 * * * /BalipuspanewsTabanan.js
    #======================================================================================================================================================================
       7 */1 * * * /BeritaJatimEkbis.js
       7 */1 * * * /BeritaJatimHukum.js
       7 */1 * * * /BeritaJatimInternasional.js
       8 */1 * * * /BeritaJatimLifes.js
       8 */1 * * * /BeritaJatimMigas.js
       8 */1 * * * /BeritaJatimPenkes.js
       8 */1 * * * /BeritaJatimPeristiwa.js
       8 */1 * * * /BeritaJatimPolitik.js
       8 */1 * * * /BeritaJatimSport.js
       8 */1 * * * /BeritaJatimTekno.js
    #======================================================================================================================================================================
       8 */1 * * * /BeritasatuIndo.js
       8 */1 * * * /BeritasatuInggris.js
       8 */1 * * * /BeritasatuInternasional.js
       9 */1 * * * /BeritasatuItalia.js
       9 */1 * * * /BeritasatuJerman.js
       9 */1 * * * /BeritasatuSpanyol.js
       9 */1 * * * /BeritasatuUefa.js
    #======================================================================================================================================================================
       9 */1 * * * /BernasidBudaya.js
       9 */1 * * * /BernasidDiy.js
       9 */1 * * * /BernasidEkonomi.js
       9 */1 * * * /BernasidKesehatan.js
       9 */1 * * * /BernasidLifes.js
       9 */1 * * * /BernasidPendidikan.js
       10 */1 * * * /BernasidSport.js
       10 */1 * * * /BernasidWacana.js
    #======================================================================================================================================================================
       10 */1 * * * /BontangposBontang.js
       10 */1 * * * /BontangposDPRD.js
       10 */1 * * * /BontangposFeature.js
       10 */1 * * * /BontangposInternasional.js
       10 */1 * * * /BontangposKaltim.js
       10 */1 * * * /BontangposLensa.js
       10 */1 * * * /BontangposNasional.js
       10 */1 * * * /BontangposPemkot.js
       1/BontangposSport.js
    #======================================================================================================================================================================
       1/BrataposNasional.js
    #======================================================================================================================================================================
       1/CahayaBaruDaerah.js
    #======================================================================================================================================================================
       1/CnnEkonomi.js
       1/CnnHiburan.js
       1/CnnInternasional.js
       1/CnnLifes.js
       1/CnnNasional.js
       1/CnnSport.js
       1/CnnTekno.js
    #======================================================================================================================================================================
       1/DenposBadung.js
      1/DenposBangli.js
      1/DenposBuleleng.js
      12 */1 * * * /DenposDenpasar.js
      12 */1 * * * /DenposGianyar.js
      12 */1 * * * /DenposJembrana.js
      12 */1 * * * /DenposKarangAsem.js
      12 */1 * * * /DenposKlungkung.js
      12 */1 * * * /DenposTabanan.js
    #======================================================================================================================================================================
      12 */1 * * * /DetikBola.js
      13 */1 * * * /DetikFinance.js
      13 */1 * * * /DetikHealt.js
      13 */1 * * * /DetikHot.js
      13 */1 * * * /DetikNews.js
      13 */1 * * * /DetikOto.js
    #======================================================================================================================================================================
      13 */1 * * * /GatraEkonomi.js
      13 */1 * * * /GatraHukum.js
      13 */1 * * * /GatraInternat.js
      13 */1 * * * /GatraKesehatan.js
      13 */1 * * * /GatraLifes.js
      14 */1 * * * /GatraMilenial.js
      14 */1 * * * /GatraPolitik.js
      14 */1 * * * /GatraSport.js
      14 */1 * * * /GatraTekno.js
    #======================================================================================================================================================================
      14 */1 * * * /HarianBangsaJatim.js
    #======================================================================================================================================================================
      14 */1 * * * /HarianBhirawaEkbis.js
      14 */1 * * * /HarianBhirawaJatim.js
      14 */1 * * * /HarianBhirawaNasional.js
      14 */1 * * * /HarianBhirawaPendidikan.js
      14 */1 * * * /HarianBhirawaSport.js
      15 */1 * * * /HarianBhirawaSurabaya.js
      15 */1 * * * /HarianBhirawaTajuk.js
      15 */1 * * * /HarianBhirawaUtama.js
      15 */1 * * * /HarianBhirawaUtamaDua.js
    #======================================================================================================================================================================
      15 */1 * * * /HarianJogjaBola.js
      15 */1 * * * /HarianJogjaEkbis.js
      15 */1 * * * /HarianJogjaHiburan.js
      15 */1 * * * /HarianJogjaJPBantul.js
      15 */1 * * * /HarianJogjaJPgunungKidul.js
      15 */1 * * * /HarianJogjaJPjogja.js
      16 */1 * * * /HarianJogjaJPkulonProgo.js
      16 */1 * * * /HarianJogjaJPsleman.js
      16 */1 * * * /HarianJogjaLifes.js
      16 */1 * * * /HarianJogjaNews.js
      16 */1 * * * /HarianJogjaOpini.js
      16 */1 * * * /HarianJogjaOto.js
      16 */1 * * * /HarianJogjaSport.js
      16 */1 * * * /HarianJogjaTekno.js
      16 */1 * * * /HarianJogjaWisata.js
    #======================================================================================================================================================================
      16 */1 * * * /HarianMerapiCermin.js
      17 */1 * * * /HarianMerapiHerbal.js
      17 */1 * * * /HarianMerapiKearifan.js
      17 */1 * * * /HarianMerapiLifes.js
      17 */1 * * * /HarianMerapiNews.js
      17 */1 * * * /HarianMerapiPeristiwa.js
      17 */1 * * * /HarianMerapiSeniHiburan.js
      17 */1 * * * /HarianMerapiSport.js
    #======================================================================================================================================================================
      17 */1 * * * /InfoBandungCreative.js
      17 */1 * * * /InfoBandungKulinar.js
      17 */1 * * * /InfoBandungLifes.js
      18 */1 * * * /InfoBandungMandalawangi.js
      18 */1 * * * /InfoBandungOpini.js
      18 */1 * * * /InfoBandungOto.js
      18 */1 * * * /InfoBandungTekno.js
    #======================================================================================================================================================================
      18 */1 * * * /JatimPostDewan.js
      18 */1 * * * /JatimPostGubernuran.js
      18 */1 * * * /JatimPostJatim.js
      18 */1 * * * /JatimPostKriminal.js
      18 */1 * * * /JatimPostNasional.js
      18 */1 * * * /JatimPostPariwisata.js
      19 */1 * * * /JatimPostPendidikan.js
    #======================================================================================================================================================================
      19 */1 * * * /KabarJagadEkbis.js
    #======================================================================================================================================================================
      19 */1 * * * /KabarJombangPeristiwa.js
    #======================================================================================================================================================================
      19 */1 * * * /KalselposBanjarBaru.js
      19 */1 * * * /KalselposBanjarmasin.js
      19 */1 * * * /KalselposBankKalsel.js
      19 */1 * * * /KalselposBaritoKuala.js
      19 */1 * * * /KalselposBeritaUtama.js
      19 */1 * * * /KalselposHss.js
      19 */1 * * * /KalselposHst.js
      20 */1 * * * /KalselposHsu.js
      20 */1 * * * /KalselposHukum.js
      20 */1 * * * /KalselposKalimantan.js  
      20 */1 * * * /KalselposKotaBaru.js
      20 */1 * * * /KalselposSport.js
    #======================================================================================================================================================================
      20 */1 * * * /KompasBola.js
      20 */1 * * * /KompasEdu.js
      20 */1 * * * /KompasHype.js
      20 */1 * * * /KompasLifes.js
      20 */1 * * * /KompasMoney.js
      21 */1 * * * /KompasNews.js
      21 */1 * * * /KompasOto.js
      21 */1 * * * /KompasProp.js
      21 */1 * * * /KompasSains.js
      21 */1 * * * /KompasTekno.js
      21 */1 * * * /KompasTravel.js
      21 */1 * * * /KompasTren.js
    #======================================================================================================================================================================
      21 */1 * * * /KoranMemoPeristiwa.js
    #======================================================================================================================================================================
      21 */1 * * * /Liputan6Bisnis.js
      21 */1 * * * /Liputan6Bola.js
      22 */1 * * * /Liputan6Citizen.js
      22 */1 * * * /Liputan6Disabilitas.js
      22 */1 * * * /Liputan6Global.js
      22 */1 * * * /Liputan6Health.js
      22 */1 * * * /Liputan6Hot.js
      22 */1 * * * /Liputan6Lifes.js
      22 */1 * * * /Liputan6News.js
      22 */1 * * * /Liputan6Onoff.js
      22 */1 * * * /Liputan6Otomotif.js
      22 */1 * * * /Liputan6Ramadhan.js
      23 */1 * * * /Liputan6Regional.js
      23 */1 * * * /Liputan6Showbizz.js
      23 */1 * * * /Liputan6Surabaya.js
      23 */1 * * * /Liputan6Tekno.js
    #======================================================================================================================================================================
      23 */1 * * * /MalangPostAdveturial.js
      23 */1 * * * /MalangPostAremaSport.js
      23 */1 * * * /MalangPostBola.js
      23 */1 * * * /MalangPostBudaya.js
      23 */1 * * * /MalangPostEkonomi.js
      23 */1 * * * /MalangPostEvent.js
      24 */1 * * * /MalangPostFakta.js
      24 */1 * * * /MalangPostFeatures.js
      24 */1 * * * /MalangPostGenzi.js
      24 */1 * * * /MalangPostInternasional.js
      24 */1 * * * /MalangPostJawatimur.js
      24 */1 * * * /MalangPostKesehatan.js
      24 */1 * * * /MalangPostKodew.js
      24 */1 * * * /MalangPostKomunitas.js
      24 */1 * * * /MalangPostKota.js
      24 */1 * * * /MalangPostKotaBatu.js
      25 */1 * * * /MalangPostKriminal.js
      25 */1 * * * /MalangPostKulinar.js
      25 */1 * * * /MalangPostLipsus.js
      25 */1 * * * /MalangPostMalangRaya.js
      25 */1 * * * /MalangPostNasional.js
      25 */1 * * * /MalangPostOpini.js
      25 */1 * * * /MalangPostPendidikan.js
      25 */1 * * * /MalangPostPolitik.js
      25 */1 * * * /MalangPostProperti.js
      25 */1 * * * /MalangPostRedakturTamu.js
      26 */1 * * * /MalangPostReligi.js
      26 */1 * * * /MalangPostSelebriti.js
      26 */1 * * * /MalangPostSenam.js
      26 */1 * * * /MalangPostSport.js
      26 */1 * * * /MalangPostTechnocell.js
      26 */1 * * * /MalangPostTokoh.js
      26 */1 * * * /MalangPostUmkm.js
      26 */1 * * * /MalangPostWisata.js
    #======================================================================================================================================================================
      26 */1 * * * /MemontumBangkalan.js
      26 */1 * * * /MemontumBanyuwangi.js
      27 */1 * * * /MemontumBlitar.js
      27 */1 * * * /MemontumBondowoso.js
      27 */1 * * * /MemontumGresik.js
      27 */1 * * * /MemontumJember.js
      27 */1 * * * /MemontumJombang.js
      27 */1 * * * /MemontumKabupatenMalang.js
      27 */1 * * * /MemontumKediri.js
      27 */1 * * * /MemontumKotaBatu.js
      27 */1 * * * /MemontumKotaMalang.js
      27 */1 * * * /MemontumLamongan.js
      28 */1 * * * /MemontumLumajang.js
      28 */1 * * * /MemontumMojokerto.js
      28 */1 * * * /MemontumPasuruan.js
      28 */1 * * * /MemontumProbolinggo.js
      28 */1 * * * /MemontumSampang.js
      28 */1 * * * /MemontumSidoarjo.js
      28 */1 * * * /MemontumSituBondo.js
      28 */1 * * * /MemontumSurabaya.js
      28 */1 * * * /MemontumTrenggalek.js
      28 */1 * * * /MemontumTulungAgung.js
    #======================================================================================================================================================================
      29 */1 * * * /MemorandumKriminal.js
    #======================================================================================================================================================================
      29 */1 * * * /NusabaliBadung.js
      29 */1 * * * /NusabaliBangli.js
      29 */1 * * * /NusabaliBeritaFoto.js
      29 */1 * * * /NusabaliBisnis.js
      29 */1 * * * /NusabaliBuleleng.js
      29 */1 * * * /NusabaliDenpasar.js
      29 */1 * * * /NusabaliGianyar.js
      29 */1 * * * /NusabaliJani.js
      29 */1 * * * /NusabaliJembrana.js
      30 */1 * * * /NusabaliKarangasem.js
      30 */1 * * * /NusabaliKlunkung.js
      30 */1 * * * /NusabaliKonsultasi.js
      30 */1 * * * /NusabaliNasional.js
      30 */1 * * * /NusabaliNews.js
      30 */1 * * * /Nusabalinusaningnusa.js
      30 */1 * * * /NusabaliOpini.js
      30 */1 * * * /NusabaliPendidikan.js
      30 */1 * * * /NusabaliPoling.js
      30 */1 * * * /NusabaliPolitik.js
      31 */1 * * * /NusabaliSergap.js
      31 */1 * * * /NusabaliSport.js
      31 */1 * * * /NusabaliTabanan.js
    #======================================================================================================================================================================
      31 */1 * * * /NusadailyBussines.js
      31 */1 * * * /NusadailyCulture.js
      31 */1 * * * /NusadailyEntertaiment.js
      31 */1 * * * /NusadailyFashion.js
      31 */1 * * * /NusadailyFood.js
      31 */1 * * * /NusadailyHealth.js
      31 */1 * * * /NusadailyJatim.js
      32 */1 * * * /NusadailyLifes.js
      32 */1 * * * /NusadailyMetro.js
      32 */1 * * * /NusadailyNews.js
      32 */1 * * * /NusadailyNusantara.js
      32 */1 * * * /NusadailyPeople.js
      32 */1 * * * /NusadailySport.js
      32 */1 * * * /NusadailyTravel.js
    #======================================================================================================================================================================
      32 */1 * * * /PetisiHukum.js
    #======================================================================================================================================================================
      32 */1 * * * /PikiranRakyatBandung.js
      32 */1 * * * /PikiranRakyatBola.js
      33 */1 * * * /PikiranRakyatEkonomi.js
      33 */1 * * * /PikiranRakyatEntertaiment.js
      33 */1 * * * /PikiranRakyatInternasional.js
      33 */1 * * * /PikiranRakyatJabar.js
      33 */1 * * * /PikiranRakyatLifes.js
      33 */1 * * * /PikiranRakyatNasional.js
      33 */1 * * * /PikiranRakyatOlahraga.js
      33 */1 * * * /PikiranRakyatPendidikan.js
      33 */1 * * * /PikiranRakyatPersib.js
      33 */1 * * * /PikiranRakyatTekno.js
    #======================================================================================================================================================================
      34 */1 * * * /PojokSatuBola.js
    #======================================================================================================================================================================
      34 */1 * * * /RadarIndonesia.js
      34 */1 * * * /RadarJogja.js
      34 */1 * * * /RadarKalteng.js
      34 */1 * * * /RadarLombok.js
      34 */1 * * * /RadarMalang.js
      34 */1 * * * /RadarSemarang.js
      34 */1 * * * /RadarSulteng.js
      34 */1 * * * /RadarTegal.js
    #======================================================================================================================================================================
      34 */1 * * * /RadarMadiunEkonomi.js
      35 */1 * * * /RadarMadiunHukum.js
      35 */1 * * * /RadarMadiunKesehatan.js
      35 */1 * * * /RadarMadiunLifes.js
      35 */1 * * * /RadarMadiunNews.js
      35 */1 * * * /RadarMadiunPendidikan.js
      35 */1 * * * /RadarMadiunSport.js
    #======================================================================================================================================================================
      35 */1 * * * /RadarMaduraBangkalan.js
      35 */1 * * * /RadarMaduraEkonomi.js
      35 */1 * * * /RadarMaduraEvent.js
      35 */1 * * * /RadarMaduraFeatures.js
      36 */1 * * * /RadarMaduraHukum.js
      36 */1 * * * /RadarMaduraPamekasan.js
      36 */1 * * * /RadarMaduraPolitik.js
      36 */1 * * * /RadarMaduraSampang.js
      36 */1 * * * /RadarMaduraSastra.js
      36 */1 * * * /RadarMaduraSport.js
      36 */1 * * * /RadarMaduraSumenep.js
    #======================================================================================================================================================================
      36 */1 * * * /RadarMalangEkonomi.js
      36 */1 * * * /RadarMalangEvent.js
      36 */1 * * * /RadarMalangKanjuruhan.js
      37 */1 * * * /RadarMalangKotaBatu.js
      37 */1 * * * /RadarMalangKotaMalang.js
      37 */1 * * * /RadarMalangLifes.js
      37 */1 * * * /RadarMalangPendidikan.js
      37 */1 * * * /RadarMalangSport.js
      37 */1 * * * /RadarMalangTekno.js
    #======================================================================================================================================================================
      37 */1 * * * /RadarTulungagung.js
      37 */1 * * * /RadarTulungagungBlitar.js
      37 */1 * * * /RadarTulungagungEkonomi.js
      37 */1 * * * /RadarTulungagungEvent.js
      38 */1 * * * /RadarTulungagungFeatures.js
      38 */1 * * * /RadarTulungagungHukum.js
      38 */1 * * * /RadarTulungagungPendidikan.js
      38 */1 * * * /RadarTulungagungPolitik.js
      38 */1 * * * /RadarTulungagungThematic.js
    #======================================================================================================================================================================
      38 */1 * * * /RilisBisnis.js
      38 */1 * * * /RilisWawancara.js
    #======================================================================================================================================================================
      38 */1 * * * /SekilasMediaNasional.js
    #======================================================================================================================================================================
      38 */1 * * * /SinarTaniAgrisarana.js
      38 */1 * * * /SinarTaniAkuamina.js
      39 */1 * * * /SinarTaniFamily.js
      39 */1 * * * /SinarTaniHorti.js
      39 */1 * * * /SinarTaniIndustri.js
      39 */1 * * * /SinarTaniKebun.js
      39 */1 * * * /SinarTaniPangan.js
      39 */1 * * * /SinarTaniPenyuluhan.js
      39 */1 * * * /SinarTaniProfil.js  
      39 */1 * * * /SinarTaniTekno.js
      39 */1 * * * /SinarTaniTernak.js
      39 */1 * * * /SinarTaniUsaha.js
    #======================================================================================================================================================================
      44 */1 * * * /SuaraJatimPostDaerah.js
      44 */1 * * * /SuaraMediaEkbis.js
      44 */1 * * * /SuaraMerdekaBola.js
    #======================================================================================================================================================================
      44 */1 * * * /TempoNasional.js
    #======================================================================================================================================================================
      45 */1 * * * /TimesindonesiaDaerah.js
      45 */1 * * * /TimesindonesiaEkonomi.js
      45 */1 * * * /TimesindonesiaEntertaiment.js
      45 */1 * * * /TimesindonesiaInternasional.js
      45 */1 * * * /TimesindonesiaKetahanan.js
      45 */1 * * * /TimesindonesiaLifes.js
      41 */1 * * * /TimesindonesiaNasional.js
      41 */1 * * * /TimesindonesiaPemerintah.js
      41 */1 * * * /TimesindonesiaPolitik.js
    #======================================================================================================================================================================
      41 */1 * * * /TribunBisnis.js
      41 */1 * * * /TribunHealt.js
      41 */1 * * * /TribunInternat.js
      41 */1 * * * /TribunJateng.js
      41 */1 * * * /TribunJogja.js
      41 */1 * * * /TribunLifes.js
      41 */1 * * * /TribunMetro.js
      42 */1 * * * /TribunNasional.js
      42 */1 * * * /TribunOto.js
      42 */1 * * * /TribunPontianak.js
      42 */1 * * * /TribunRegional.js
      42 */1 * * * /TribunSeleb.js
      42 */1 * * * /TribunSport.js
      42 */1 * * * /TribunSuperSkor.js
      42 */1 * * * /TribunTecno.js
      42 */1 * * * /TribunTravel.js
    #======================================================================================================================================================================
      42 */1 * * * /WaspadaAceh.js
      43 */1 * * * /WaspadaAcehEntertaiment.js
      43 */1 * * * /WaspadaAcehFeatures.js
      43 */1 * * * /WaspadaAcehInternasional.js
      43 */1 * * * /WaspadaAcehIpa.js
      43 */1 * * * /WaspadaAcehKuliner.js
      43 */1 * * * /WaspadaAcehOpini.js
      43 */1 * * * /WaspadaAcehLaporanKhusus.js
      43 */1 * * * /WaspadaAcehLifes.js
      43 */1 * * * /WaspadaAcehNasional.js
      43 */1 * * * /WaspadaAcehPariwara.js
      44 */1 * * * /WaspadaAcehProfil.js
      44 */1 * * * /WaspadaAcehSport.js
      44 */1 * * * /WaspadaAcehSumut.js
      44 */1 * * * /WaspadaAcehTausiah.js
      44 */1 * * * /WaspadaAcehTeknologi.js
      44 */1 * * * /WaspadaAcehWisata.js
    #======================================================================================================================================================================



































































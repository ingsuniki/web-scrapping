# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
# ============================= store on mongodb ===================== 
import pymongo
import datetime

host_name = 'localhost'
port_name = 27017
db_name = 'portal_py'
collection_name = 'list_portal'

ITEM_PIPELINES = {
    'mybot.pipelines.validate.ValidateMyItem': 300,
    'mybot.pipelines.validate.StoreMyItem': 800,
}

class ScrapyportalPipeline(object):
    
    # main program or call of the function tobe execute 
    def __init__(self):
        self.conn = pymongo.MongoClient(
            host_name,
            port_name
        )
        db = self.conn[db_name]
        self.collection = db[collection_name]   

    def process_item(self, item, spider):
        try:
            # print (item['datetime_ms'])
            self.collection.insert(dict(item))
            return item
        # SKip log in duplication data error
        except Exception:
            pass


# ===============================================================================================
# ============================= end code store on mongodb =====================



